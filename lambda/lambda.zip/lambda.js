const AWS = require("aws-sdk");
const util = require("util");
const s3 = new AWS.S3();
const s3Archiver = require("lambda-s3-archiver");

module.exports = {
  handler: async (event) => {
    console.log(
      "Reading options from event:\n",
      util.inspect(event, { depth: 5 })
    );
    const srcBucket = "upload-download-test-bucket";
    // const srcKey = event.body.fileName;
    const { fileNames } = event.body;

    console.log("running archiver...");
    const result = await s3Archiver.archive(
      "upload-download-test-bucket",
      "exampleFiles",
      fileNames,
      "zipped/archive",
      "zip"
    );
    console.log(result);
    try {
      const allObjects = await s3.listObjects({ Bucket: srcBucket }).promise();

      console.log("allObjects in bucket ", JSON.stringify(allObjects));
      // const params = {
      //   Bucket: srcBucket,
      //   Key: srcKey,
      // };
      // const s3File = await s3.getObject(params).promise();
      // const copy = await s3.putObject({
      //   Bucket: srcBucket,
      //   Key: `copy-${srcKey}`,
      // });
      return JSON.stringify({
        statusCode: 200,
        message: "success",
        result,
      });
    } catch (error) {
      console.log(error);
      throw error;
    }
  },
};
